using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

public class Player_script : NetworkBehaviour
{
    public float velocidade = 7f;
    public float velocidadeRotacao = 180f;

    private Rigidbody rb;
    private Animator animator;

    private NetworkVariable<int> randomNumber = new NetworkVariable<int>(1, NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Owner);

    [SerializeField]
    private Transform spawnedObjectPrefab;
    private Transform spawnedObjectTransform;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        Debug.Log(OwnerClientId + " - randomNumber: " + randomNumber.Value);

        if (!IsOwner)
        {
            return;
        }

        if (Input.GetKeyDown(KeyCode.Y))
        {
            TestServerRpc("Y");
        }

        if (Input.GetKeyDown(KeyCode.U))
        {
            TestClientRpc("U");
        }

        if (Input.GetKeyDown(KeyCode.I)) 
        {
            spawnedObjectTransform = Instantiate(spawnedObjectPrefab);
            spawnedObjectTransform.GetComponent<NetworkObject>().Spawn(true);
            print("I");
        }

        if (Input.GetKeyDown(KeyCode.O))
        {
            Destroy(spawnedObjectTransform.gameObject);
            print("O");
        }

        float movimentoHorizontal = Input.GetAxis("Horizontal");
        float movimentoVertical = Input.GetAxis("Vertical");

        Vector3 movimento = new Vector3(movimentoHorizontal, 0f, movimentoVertical);

        rb.velocity = movimento * velocidade;

        if (movimento != Vector3.zero)
        {
            Quaternion rotacaoDesejada = Quaternion.LookRotation(movimento);
            rb.rotation = Quaternion.Slerp(rb.rotation, rotacaoDesejada, Time.deltaTime * velocidadeRotacao);
        }

        animator.SetFloat("Walk", movimento.magnitude);

        if (Input.GetKeyDown(KeyCode.T))
        {
            randomNumber.Value = Random.Range(0, 100);
        }
    }

    public override void OnNetworkSpawn()
    {
        randomNumber.OnValueChanged += (int valorAnterior, int novoValor) =>
        {
            Debug.Log(OwnerClientId + " - randomNumber: " + randomNumber.Value);
        };
    }

    //[ServerRpc]

    //private void TestServerRpc()
    //{
    //    Debug.Log("TestServerRpc " + OwnerClientId);
    //}

    [ServerRpc]
    private void TestServerRpc(string message)
    {
        Debug.Log("TestServerRpc " + OwnerClientId + " : " + message);
    }

    [ClientRpc]
    private void TestClientRpc(string message)
    {
        Debug.Log("TestClientRpc " + OwnerClientId + " : " + message);
    }

}