using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Coletavel : MonoBehaviour
{
    public int pontos_coletados = 0;

    public int P1_pontos_coletados = 0;
    public int P2_pontos_coletados = 0;

    public float aleX;
    public float aleZ;

    public bool Definicao_P1 = true;

    public Transform MarcadorX1;
    public Transform MarcadorX2;

    public Transform MarcadorZ1;
    public Transform MarcadorZ2;

    public GameObject Player1;

    public TextMeshProUGUI P1_TMP;
    public TextMeshProUGUI P2_TMP;

    // Start is called before the first frame update
    void Start()
    {
        print("Pontos coletados: " + pontos_coletados);
        print("Player 1: " + P1_pontos_coletados);
        print("Player 2: " + P2_pontos_coletados);
    }

    // Update is called once per frame
    void Update()
    {
        P1_TMP.text = P1_pontos_coletados.ToString();
        P2_TMP.text = P2_pontos_coletados.ToString();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag.Equals("Player") && Definicao_P1)
        {
            Posicao_aleatoria();
            Definicao_P1 = false;
            transform.position = new Vector3(aleX, other.transform.position.y, aleZ);
            pontos_coletados++;
            print("Pontos totais coletados: " + pontos_coletados);
            Player1 = other.gameObject;
        }

        //Player 1
        if (other.gameObject == Player1)
        {
            Posicao_aleatoria();
            transform.position = new Vector3(aleX, other.transform.position.y, aleZ);
            P1_pontos_coletados++;
            print("P1 pontos: " + P1_pontos_coletados);
        }

        //Player 2
        else
        {
            Posicao_aleatoria();
            transform.position = new Vector3(aleX, other.transform.position.y, aleZ);
            P2_pontos_coletados++;
            print("P2 pontos: " + P2_pontos_coletados);
        }
    }

    public void Posicao_aleatoria()
    {
        aleX = Random.Range(MarcadorX1.transform.position.x, MarcadorX2.transform.position.x);
        aleZ = Random.Range(MarcadorZ1.transform.position.z, MarcadorZ2.transform.position.z);
        print("Posicao X: " + aleX);
        print("Posicao Z: " + aleZ);
    }
}
